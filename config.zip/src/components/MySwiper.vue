<template>
   <div class="swiper-container" :class="swiperOpt.container">
        <div class="swiper-wrapper">
            <div v-for="(item,index) in this.swiperOpt.imgs" :key="index" class="swiper-slide"><img :src="item"></div>
        </div>
        <div v-if="swiperOpt.num==0" class="swiper-pagination"></div>
    </div>
</template>
<script>
    export default {
        name:"MySwiper",
        props:["swiperOpt","nums"],
        data(){
            return{
                
            }
        },
        beforeMount(){
            // new Swiper('.'+this.swiperOpt.container,this.swiperOpt);
            // console.log(this.swiperOpt)
            // this.swiperOpt=""
        },updated(){
            // console.log(this.swiperOpt.num)
            // new Swiper('.'+this.swiperOpt.container,this.swiperOpt);
        }
    }
</script>
<style scoped>

.swiper-container{
    width: 10rem
}
.swiper-container img{
    display: block;
    width: 10rem;
    height: 3.733333rem /* 280/75 */;
}
</style>


